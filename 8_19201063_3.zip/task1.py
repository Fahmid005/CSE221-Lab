fr = open('input.txt','r')
# initialize empty list to append input data 
data = []
# initialize empty dict 
graph = {}

for i in fr:
    data.append(i.split())
#print(data)

total = int(data[0][0])
data = data[1::]
#print(data)

for i in data:
    key = int(i[0])
    val = i[1::]
    for j in range(len(val)):
        val[j] = int(val[j])
        
    graph[key] = val
#print(graph)

fr.close()