import heapq
import math

def Dijkstra(Graph, source):
    dist = []
    for i in range(len(Graph)+1):
        dist.append(math.inf)
    dist[source] = 0
    
    Q = []
    
    visited = []
    for i in range(len(Graph)+1):
        visited.append(0)
        
    prev = []
    for i in range(len(Graph)+1):
        prev.append(0)
    
    for v in Graph:
        heapq.heappush(Q, (dist[v], v))

    while len(Q) != 0:
        u, l = heapq.heappop(Q)
        
        if visited[l]:
            continue
        
        visited[l] = True
        
        for v in Graph[l]:
            alt = u + v[1]
            
            if alt < dist[v[0]]:
                dist[v[0]] = alt
                prev[v[0]] = l
                heapq.heappush(Q, (dist[v[0]], v[0]))
                 
    return prev

fr = open('input1.txt', 'r')
fw = open('output2.txt', 'w')

G ={}

data = []

for i in fr:
    data.append(i)
    
for i, j in enumerate(data):
    data[i] = j.replace('\n','')
    
testCase = int(data[0])
data = data[1:]
info = []

for i in data:
    temp = i.split()
    info.append(temp)
    
pointer = 0
for i in info:
    
    if len(i) == 3:
        continue

    if len(i) == 2:
        n = int(i[0])
        e = int(i[1])
        
        if n == 1:
            pointer += 1
            G[n] = []
            
            result = Dijkstra(G,1)
            result = result[1:]
            
            for i in result:
                if i == 0:
                    fw.write("1\n")
            
        else:
            pointer += 1
            for j in range(e):
                v1 = int(info[pointer][0])
                v2 = int(info[pointer][1])
                titan = int(info[pointer][2])
                
                if v1 not in G:
                    G[v1] = []
                
                if v2 not in G:
                    G[v2] = []
                
                G[v1].append( (v2, titan) )
                
                pointer += 1
            
            result = Dijkstra(G,1)

            task2 = ""
            task2_list = []
            task2_list.append(len(G))
            index = len(G)
            
            while index != 1:
                task2_list.append(result[index])
                index = result[index]
                
            task2_list.reverse()
            
            for i in task2_list:
                task2 += str(i)+" "
                
            fw.write(task2 + "\n")
            
            G = {}
                
fr.close()
fw.close()


