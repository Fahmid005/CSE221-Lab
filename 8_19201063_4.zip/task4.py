import heapq
import math

def Network(Graph, source):
    dist = []
    for i in range(len(Graph)+1):
        dist.append(-math.inf)
    dist[source] = 0
    
    Q = []
    
    visited = []
    for i in range(len(Graph)+1):
        visited.append(0)
        
    prev = []
    for i in range(len(Graph)+1):
        prev.append(0)
    prev[source] = 1
    
    for v in Graph:
        heapq.heappush(Q, (dist[v], v))
        
    heapq._heapify_max(Q)
        
    while len(Q) != 0:
        u, l = heapq._heappop_max(Q)
        
        if visited[l] == 1:
            continue
        
        visited[l] = 1
        
        for v in Graph[l]:
            alt = 0
            
            if u == 0:
                alt = v[1]
            elif v[1] == 0:
                alt = u
            elif u < v[1]:
                alt = u
            else:
                alt = v[1]
                
            if alt > dist[v[0]]:
                dist[v[0]] = alt
                prev[v[0]] = l
                
                heapq.heappush(Q, (dist[v[0]], v[0]))
                heapq._heapify_max(Q)
                
    return dist

fr = open("input4.txt","r")
fw = open("output4.txt", "w")
lines = fr.read().splitlines()
test_cases = int(lines[0])
lines = lines[1:]

g = {}

count = 0
for i in range(test_cases):
    devices = int(lines[count].split()[0])
    conections = int(lines[count].split()[1])
    
    if conections == 0:
        start = devices
        g[devices] = []
        source_index = count + 1 + conections
        source = int(lines[source_index])
    elif conections > 0:
        trim_start = count + 1
        trim_end = trim_start + conections
        current_test_case = lines[trim_start:trim_end]
        source_index = count + 1 + conections
        source = int(lines[source_index])
        for i in current_test_case:
            temp = i.split()
            
            node1 = int(temp[0])
            node2 = int(temp[1])
            dr = int(temp[2])
            
            if node1 not in g:
                g[node1] = []
                
            if node2 not in g:
                g[node2] = []
                
            g[node1].append((node2, dr))
    
    dist = Network(g, source)
    dist = dist[1:]
    output = ""
    
    for i in dist:
        if i < -1:
            output += "-1 "
        else:
            output += str(i)+" "

    fw.write(output+"\n")
    
    g = {}
    count += 2 + conections
    
fr.close()
fw.close()
