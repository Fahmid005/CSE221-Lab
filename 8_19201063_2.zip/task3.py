def insertionSort(marks,std_id,fw):
    for i in range(len(marks)-1):
        temp_marks = marks[i+1]
        temp_std_id = std_id[i+1]
        j = i
        
        # descending order
        while j >= 0:
            if marks[j] < temp_marks:
                marks[j+1] = marks[j]
                std_id[j+1] = std_id[j]
            else:
                break
            
            j -= 1
        
        marks[j+1] = temp_marks
        std_id[j+1] = temp_std_id
        
    
    # write in output file 
    for i in std_id:
        fw.write(i+" ")
#================== FILE READ/WRITE ========================       
fo = open('input3.txt','r')
fw = open('output3.txt','w')
input_array = []

for i in fo:
    input_array.append(i)
    
n = int(input_array[0].replace('\n', ''))
std_id = input_array[1].replace('\n', '')
marks = input_array[2].replace('\n', '')

marks = marks.split(' ')
conv_marks = []

for i in marks:
    conv_marks.append(int(i))
    
std_id = std_id.split(' ')
    
insertionSort(conv_marks, std_id, fw)
# close files
fo.close()
fw.close()
