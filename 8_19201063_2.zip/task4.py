# -*- coding: utf-8 -*-
"""
Created on Sun Jul  4 23:38:29 2021

@author: User
"""

def mergeSort(num):
    arr = []
    if len(num) < 2:
        return num
    mid = len(num)//2
    pre_mid = mergeSort(num[:mid])
    post_mid = mergeSort(num[mid:])
    while (len(pre_mid) > 0) or (len(post_mid) > 0):
        if len(pre_mid) > 0 and len(post_mid) > 0:
            if pre_mid[0] > post_mid[0]:
                arr.append(post_mid[0])
                post_mid.pop(0)
            else:
                arr.append(pre_mid[0])
                pre_mid.pop(0)
        elif len(post_mid) > 0:
            for i in post_mid:
                arr.append(i)
                post_mid.pop(0)
        else:
            for i in pre_mid:
                arr.append(i)
                pre_mid.pop(0)
    return arr
#=================== FILE READ/WRITE =============================
fo = open("input4.txt", "r")
fw = open("output4.txt", "w")
input_arr = []
for i in fo:
    input_arr.append(i)
data = input_arr[1].split(" ")
for i in range(len(data)):
    data[i] = int(data[i])

sorted_data = mergeSort(data)
for i in sorted_data:
    fw.write(str(i)+" ")

fo.close()
fw.close()