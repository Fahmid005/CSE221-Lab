#------------- OPTIMIZED BUBBLE SORT ------------
# BEST CASE SCENARIO: Bubble sort takes time complexity O(n) when array is already sorted
  
def bubbleSort(arr):
    # Iterate through all array elements
    i = 0
    while i <= len(arr)-1:
        swap = False
        i += 1
        # Iterate through last i elements
        j = 0
        while j <= len(arr)-i-1:
            if arr[j] > arr[j+1]:
                # Swap if jth element > (j+1)th element
                arr[j] , arr[j+1] = arr[j+1] , arr[j]
                swap = True
            j += 1
        # If no elements swapped, break the loop
        # If already sorted, break 
        if swap == False:
            break
    return arr
#=============== FILE READ/WRITE =================
fo = open('input1.txt','r')
fw = open('output1.txt','w')

input_arr = []
for i in fo:
    input_arr.append(i) 
# split by white-space " "
num = input_arr[1].split(" ")

for i in range(len(num)):
    num[i] = int(num[i])
# call sort func
sorted_arr = bubbleSort(num)
# Write OUTPUT
for i in sorted_arr:
    fw.write(str(i)+" ")
# Close files    
fo.close()
fw.close()