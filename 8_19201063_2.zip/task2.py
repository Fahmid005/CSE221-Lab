def selectionSort(arr):
    # Iterate through all array elements
    i = 0
    while i <= len(arr) - 1:
        # select a minimum element for comparison 
        minimum = i
        # Iterate from the next elements
        j = i+1
        while j <= len(arr) - 1:
            if int(arr[minimum]) > int(arr[j]):
                minimum = j
            j += 1
        # Swap
        temp = arr[i]
        arr[i] = arr[minimum]
        arr[minimum] = temp
    
        i += 1
    return arr
#================= FILE READ/ WRITE ==================
fo = open('input2.txt','r')
fw = open('output2.txt','w')
input_lines = []
for i in fo:
    input_lines.append(i)

data = input_lines[0].split(' ')
iterator = int(data[1].replace('\n',''))
data = input_lines[1].split(' ')

sortedarray = selectionSort(data)

for i in range(iterator):
    fw.write(str(sortedarray[i])+" ")
# close files 
fo.close()
fw.close()