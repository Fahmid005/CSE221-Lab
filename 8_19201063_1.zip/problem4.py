# -*- coding: utf-8 -*-
"""
Created on Sun Jun 27 21:20:11 2021

@author: User
"""

read_file = open("input4.txt","r")
output_file = open("output4.txt","w")
myInput = []
A = []
B = []
C = []


for i in read_file:
  if i.replace(" \n","") != "":
    myInput.append(i.replace("\n",""))
#print(myInput)
n = int(myInput[0])

myInput = myInput[1:]


for i in range(n*2):
  if i < n:
    temp = myInput[i].split(" ")
    for j in range(len(temp)):
      temp[j] = int(temp[j])
    A.append(temp)
  else:
    temp = myInput[i].split(" ")
    for j in range(len(temp)):
      temp[j] = int(temp[j])
    B.append(temp)



for i in range(n):
  temp = []
  for x in range(n):
    temp.append(0)
  C.append(temp)



for i in range(n):
  for j in range(n):
    for k in range(n):
      C[i][j] += A[i][k] * B[k][j]



for i in range(n):
  for j in range(n):
    output_file.write(str(C[i][j])+" ")

  output_file.write("\n")

read_file.close()
output_file.close()


