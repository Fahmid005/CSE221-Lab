# PALINDROME CHECK METHOD 

def isPalindrome(string):
    if string == None:
        return f"{string} is not a palindrome"
    mid = len(string)//2
    for i in range(mid):
        if string[i] != string[len(string) - i - 1]:
            return f"{string} is not a palindrome"
        
    return f"{string} is a palindrome"

# PARITY CHECK METHOD

def isParity(num):
    # Check for float numbers first 
    if "." in num:
        result = str(float(num)) + " cannot have parity"
        return result
    if int(num) % 2 == 0:
        return f"{num} has a even parity"
    else:
        return f"{num} has a odd parity"
    
# I/O file read write


inputFile = open("input.txt", "r")
recordFile = open("record.txt", "w")
outputFile = open("output.txt", "w")

# variable declaration

arr = []

evenCount = 0
oddCount = 0
noParityCount = 0
palindromeCount = 0
notPalindromeCount = 0
lineCount = 0

# Store input.txt content in array 
for i in inputFile:
    arr.append(i)
lineCount = len(arr)

# __main__ function
for i in arr:
    splitter = i.split(" ")
    num = splitter[0]
    word = splitter[1]
    lineSep = word.split("\n")  
    
    parityCheck = isParity(num)
    palindromeCheck = isPalindrome(lineSep[0])
    
    if "even parity" in parityCheck:
        evenCount += 1
    elif "odd parity" in parityCheck:
        oddCount += 1
    elif "cannot have parity" in parityCheck:
        noParityCount += 1
    
    if "is a palindrome" in palindromeCheck:
        palindromeCount += 1
    else:
        notPalindromeCount += 1
    
    result = parityCheck + " and " + palindromeCheck
    outputFile.write(str(result)+"\n")
        
# Percentage 
evenPercentage = (evenCount/lineCount) * 100
oddPercentage = (oddCount/lineCount) * 100
noParityPercentage = (noParityCount/lineCount) * 100
notPalindromePercentage =  (notPalindromeCount/lineCount) * 100
palindromePercentage = (palindromeCount/lineCount) * 100


# Write output 
recordFile.write("Percentage of odd parity: "+str(oddPercentage)+"%\n")
recordFile.write("Percentage of even parity: "+str(evenPercentage)+"%\n")
recordFile.write("Percentage of no parity: "+str(noParityPercentage)+"%\n")
recordFile.write("Percentage of palindrome: "+str(palindromePercentage)+"%\n")
recordFile.write("Percentage of non-palindrome: "+str(notPalindromePercentage)+"%\n")

    
inputFile.close()
outputFile.close()
recordFile.close()














