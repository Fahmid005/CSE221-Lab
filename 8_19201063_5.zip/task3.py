import heapq

def Jnj(t, hours, c):
    # Sort the task hours in ascending order
    i = 0
    while i < len(hours):
        j = 0
        while j < (len(hours)-i-1):
            if hours[j] > hours[j+1]:
                # swap value
                hours[j] , hours[j+1] = hours[j+1] , hours[j]
            j += 1
        i += 1 
    
    
    # Initialize time counter for jack and jill
    # J_hours---> Jack, j_hours-----> Jill
    J_hours = 0
    j_hours = 0
    # Initialize task arr to append task sequence 
    task_arr = []
    
    # Initiliaze Jack arr with default 0s 
    Jack = [0] * t
    

    for i in range(len(c)):
        if c[i] == "J":
            J_time = int(hours.pop(0))
            J_hours += J_time
            heapq.heappush(Jack,-J_time
                           )
            task_arr += [J_time]

        if c[i] == "j":
            j_time = int(heapq.heappop(Jack))*(-1)
            j_hours += j_time
    
            task_arr += [j_time]

    
    for i in range( len(task_arr) ):
        fw.write(str(task_arr[i]) + "")

    fw.write("\nJack will work for " + str(J_hours) + " hours\n")
    fw.write("Jill will work for " + str(j_hours) + " hours")


#-------------------------- Tester Code----------------------
fr = open("task3_input.txt", "r")
fw = open("task3_output.txt", "w")

task_count = fr.readline()
t = int(task_count)
num = fr.readline()
hours = list( map( str, num.split() ) )
c = fr.readline()

#Function call 
Jnj(t,hours,c)
#File close 
fr.close()
fw.close()
