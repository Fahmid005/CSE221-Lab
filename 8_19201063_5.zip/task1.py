# Selection sort
# Sort array in ascending end time order 
def Assignment_Selection(arr, n):
    i = 0
    while i < len(arr):
        minimum = int(arr[i][1])
        min_index = i

        j = i+1
        while j < len(arr):
            if int(arr[j][1]) <= minimum:
                minimum = int(arr[j][1])
                min_index = j
            
            j += 1
            
        arr[i], arr[min_index] = arr[min_index] , arr[i]
        
        i += 1 
    
    
    time = compare_time(arr)

    # print maximum assignment count
    fw.write( str(len(time)) + "\n")
    
    # print start and end time 
    for count in range(len(time)):
        fw.write(str(time[count][0]) + " " + str(time[count][1]) + "\n")



def compare_time(arr):
    start = int(arr[0][0])
    end = int(arr[0][1])
    
    compare_arr = [[str(start), str(end)]]
    
    for i in range(len(arr)):
        start1 = int(arr[i][0])
        
        if end <= start1:
            start = end
            end = int(arr[i][1])
            compare_arr.append(arr[i])
    return compare_arr

#----------------- Tester code -----------------------------
fr = open("task1_input.txt", "r")
fw = open("task1_output.txt", "w")


assignment_count = fr.readline()
n = int(assignment_count)

data = []
for count in range(n):
    num = fr.readline()
    timing =  list( map( str, num.split() ) )
    data.append(timing)
#Function call
Assignment_Selection(data, n)
# File close
fr.close()
fw.close()

