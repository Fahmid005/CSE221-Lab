def Assignment_Selection(arr, n, p):
    # Selection sort
    # Sort array in ascending end time order
    i = 0
    while i < len(arr):
        minimum = int(arr[i][1])
        min_index = i
    
        j = i + 1
        while j < len(arr):
            if int(arr[j][1]) <= minimum:
                minimum = int(arr[j][1])
                min_index = j
            j += 1
        # Swap positions        
        arr[i] , arr[min_index] = arr[min_index] , arr[i]
    
        i += 1
    
    
    # Initialize Queue 
    Q = []
    for count in range(p):
        Q.append(arr.pop(0))
    
    final = []
    counter = 0
    for i in range(p):
        arr.insert(0, Q[i])
        tasks = compare_time(arr)
        final.append(tasks)
        
        for j in range(len(tasks)):
            arr.remove(tasks[j])
            counter += 1
    
    #Print assignment/task count 
    fw.write(str(counter))

def compare_time(arr):
    start = int(arr[0][0])
    end = int(arr[0][1])
    
    final = [[str(start), str(end)]]
    
    for i in range(len(arr)):
        start1 = int(arr[i][0])
        
        if end <= start1:
            start = end
            end = int(arr[i][1])
            final.append(arr[i])
    
    return final


#-------------Tester Code-----------------------
fr = open("task2_input.txt", "r")
fw = open("task2_output.txt", "w")

num = fr.readline()
line = list( map( str, num.split() ) )

assingment_count = line[0]
people_count = line[1]
n = int(assingment_count)
p = int(people_count)

data = []
for count in range(n):
    num = fr.readline()
    timing = list( map( str, num.split() ) )
    data.append(timing)

# Function call
Assignment_Selection(data, n, p)
#File Close
fr.close()
fw.close()